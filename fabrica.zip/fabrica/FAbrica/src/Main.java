public class Main {
    public static void main(String[] args) {
        factory factory = new factory();
        factory.startProduction();
        factory.runAgent(); // Inicia o agente
    }
}
