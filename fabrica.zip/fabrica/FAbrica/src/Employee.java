public class Employee {
    // Atributos do funcionário
    private int id;
    
    // Construtor
    public Employee(int id) {
        this.id = id;
    }
    
    // Getter
    public int getId() {
        return id;
    }
}
